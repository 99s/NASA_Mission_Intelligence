import json
import os
import pandas as pd

import rag_client
import llm_client
import ragas_evaluator


OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

CHROMA_DIR = "./chroma_db_openai"
COLLECTION_NAME = "nasa_space_missions_text"

TEST_DATASET = "test_questions.json"


def load_test_questions(file_path):

    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)


def run_batch_evaluation():

    collection, success, error = rag_client.initialize_rag_system(
        CHROMA_DIR,
        COLLECTION_NAME
    )

    if not success:
        print(f"Initialization failed: {error}")
        return

    questions = load_test_questions(TEST_DATASET)

    results = []

    for item in questions:

        question = item["question"]

        mission = item.get("mission", "all")

        docs_result = rag_client.retrieve_documents(
            collection,
            question,
            n_results=3,
            mission_filter=mission
        )

        context = ""

        contexts_list = []

        if docs_result and docs_result.get("documents"):

            context = rag_client.format_context(
                docs_result["documents"][0],
                docs_result["metadatas"][0]
            )

            contexts_list = docs_result["documents"][0]

        answer = llm_client.generate_response(
            OPENAI_API_KEY,
            question,
            context,
            []
        )

        scores = ragas_evaluator.evaluate_response_quality(
            question,
            answer,
            contexts_list
        )

        row = {
            "question": question,
            "mission": mission,
            "answer": answer
        }

        row.update(scores)

        results.append(row)

        print("=" * 80)
        print(f"QUESTION: {question}")
        print(f"MISSION: {mission}")
        print(f"ANSWER: {answer}")

        for metric, value in scores.items():
            print(f"{metric}: {value}")

    df = pd.DataFrame(results)

    print("\n")
    print("=" * 80)
    print("AGGREGATE METRICS")
    print("=" * 80)

    numeric_cols = df.select_dtypes(include="number").columns

    for col in numeric_cols:
        print(f"{col}: {df[col].mean():.4f}")

    df.to_csv("evaluation_results.csv", index=False)

    print("\nSaved results to evaluation_results.csv")


if __name__ == "__main__":
    run_batch_evaluation()